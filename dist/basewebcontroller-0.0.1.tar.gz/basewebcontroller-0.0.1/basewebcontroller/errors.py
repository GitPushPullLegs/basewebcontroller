class AuthenticationError(Exception):
    pass