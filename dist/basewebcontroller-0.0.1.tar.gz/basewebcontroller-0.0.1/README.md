# Base Web Controller
A Python package to be the base of my web controllers.

## Installation :
`pip install git+https://github.com/GitPushPullLegs/basewebcontroller.git`